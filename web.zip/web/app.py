from flask import Flask, render_template, request, redirect
from datetime import datetime
import sqlite3

app = Flask(__name__)

DB_PATH = "tasks.db"

STATUS_RU = {
    "new": "Новая",
    "in_progress": "В работе",
    "done": "Выполнена"
}

CATEGORY_RU = {
    "work": "Работа",
    "personal": "Личное",
    "study": "Учёба",
    "other": "Другое"
}


def create_table():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()

    cur.execute("""
        CREATE TABLE IF NOT EXISTS tasks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            description TEXT,
            status TEXT CHECK(status IN ('new','in_progress','done')) NOT NULL,
            priority INTEGER CHECK(priority BETWEEN 1 AND 5) NOT NULL,
            category TEXT CHECK(category IN ('work','personal','study','other')) NOT NULL,
            due_date TEXT,
            created_at TEXT
        )
    """)

    conn.commit()
    conn.close()


def is_due_soon(due_date):
    if not due_date:
        return False

    try:
        due_dt = datetime.strptime(due_date, "%d.%m.%Y").date()
        today = datetime.now().date()
        days_left = (due_dt - today).days
        return 0 <= days_left < 2
    except ValueError:
        return False


def get_tasks(status, priority, category, search, sort, page):
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()

    query = "SELECT * FROM tasks WHERE 1=1"
    count_query = "SELECT COUNT(*) FROM tasks WHERE 1=1"
    params = []

    if status != "all":
        query += " AND status=?"
        count_query += " AND status=?"
        params.append(status)

    if priority != "all":
        query += " AND priority=?"
        count_query += " AND priority=?"
        params.append(priority)

    if category != "all":
        query += " AND category=?"
        count_query += " AND category=?"
        params.append(category)

    if search:
        query += " AND title LIKE ?"
        count_query += " AND title LIKE ?"
        params.append(f"%{search}%")

    sort_options = {
        "created_desc": "id DESC",
        "created_asc": "id ASC",
        "priority_desc": "priority DESC",
        "priority_asc": "priority ASC",
        "due_asc": "due_date ASC",
        "due_desc": "due_date DESC"
    }

    cur.execute(count_query, params)
    total_tasks = cur.fetchone()[0]

    limit = 10
    offset = (page - 1) * limit

    query += " ORDER BY " + sort_options.get(sort, "id DESC")
    query += " LIMIT ? OFFSET ?"

    cur.execute(query, params + [limit, offset])
    tasks = cur.fetchall()

    conn.close()

    tasks = [task + (is_due_soon(task[6]),) for task in tasks]

    total_pages = (total_tasks + limit - 1) // limit
    return tasks, total_pages


def get_task_by_id(task_id):
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()

    cur.execute("SELECT * FROM tasks WHERE id=?", (task_id,))
    task = cur.fetchone()

    conn.close()
    return task


def add_task(title, description, status, priority, category, due_date):
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()

    if due_date:
        due_date = datetime.strptime(due_date, "%Y-%m-%d").strftime("%d.%m.%Y")

    cur.execute("""
        INSERT INTO tasks (title, description, status, priority, category, due_date, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    """, (
        title,
        description,
        status,
        priority,
        category,
        due_date,
        datetime.now().strftime("%d.%m.%Y %H:%M:%S")
    ))

    conn.commit()
    conn.close()


def update_task(task_id, title, description, status, priority, category, due_date):
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()

    cur.execute("""
        UPDATE tasks
        SET title=?, description=?, status=?, priority=?, category=?, due_date=?
        WHERE id=?
    """, (
        title,
        description,
        status,
        priority,
        category,
        due_date,
        task_id
    ))

    conn.commit()
    conn.close()


def delete_task(task_id):
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()

    cur.execute("DELETE FROM tasks WHERE id=?", (task_id,))

    conn.commit()
    conn.close()


@app.route("/")
def index():
    create_table()

    status = request.args.get("status", "all")
    priority = request.args.get("priority", "all")
    category = request.args.get("category", "all")
    search = request.args.get("search", "")
    sort = request.args.get("sort", "created_desc")
    page = int(request.args.get("page", 1))

    tasks, total_pages = get_tasks(status, priority, category, search, sort, page)

    return render_template(
        "index.html",
        tasks=tasks,
        status=status,
        priority=priority,
        category=category,
        search=search,
        sort=sort,
        page=page,
        total_pages=total_pages,
        status_ru=STATUS_RU,
        category_ru=CATEGORY_RU
    )


@app.route("/add", methods=["POST"])
def add():
    title = request.form.get("title")
    description = request.form.get("description")
    status = request.form.get("status")
    priority = request.form.get("priority")
    category = request.form.get("category")
    due_date = request.form.get("due_date")

    if title:
        add_task(title, description, status, priority, category, due_date)

    return redirect("/")


@app.route("/edit/<int:task_id>", methods=["GET", "POST"])
def edit(task_id):
    task = get_task_by_id(task_id)

    if not task:
        return redirect("/")

    if task[3] == "done":
        return redirect("/")

    if request.method == "POST":
        title = request.form.get("title")
        description = request.form.get("description")
        status = request.form.get("status")
        priority = request.form.get("priority")
        category = request.form.get("category")
        due_date = request.form.get("due_date")

        if title:
            update_task(task_id, title, description, status, priority, category, due_date)

        return redirect("/")

    return render_template("edit.html", task=task)


@app.route("/delete/<int:task_id>")
def delete(task_id):
    delete_task(task_id)
    return redirect("/")


if __name__ == "__main__":
    app.run(debug=True)