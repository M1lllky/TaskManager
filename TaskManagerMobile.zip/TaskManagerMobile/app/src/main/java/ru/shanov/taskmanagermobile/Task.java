package ru.shanov.taskmanagermobile;

public class Task {
    public int id;
    public String title;
    public String description;
    public String status;
    public int priority;
    public String category;
    public String dueDate;
    public String createdAt;

    public Task(int id, String title, String description, String status,
                int priority, String category, String dueDate, String createdAt) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.status = status;
        this.priority = priority;
        this.category = category;
        this.dueDate = dueDate;
        this.createdAt = createdAt;
    }
}