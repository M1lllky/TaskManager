package ru.shanov.taskmanagermobile;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class TaskAdapter extends ArrayAdapter<Task> {

    public TaskAdapter(@NonNull Context context, @NonNull List<Task> tasks) {
        super(context, 0, tasks);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        Task task = getItem(position);

        if (convertView == null) {
            convertView = LayoutInflater.from(getContext())
                    .inflate(android.R.layout.simple_list_item_2, parent, false);
        }

        TextView text1 = convertView.findViewById(android.R.id.text1);
        TextView text2 = convertView.findViewById(android.R.id.text2);

        if (task != null) {
            text1.setText(task.title + " (" + getStatusText(task.status) + ")");
            text2.setText("Приоритет: " + task.priority +
                    " | Категория: " + getCategoryText(task.category) +
                    " | Срок: " + task.dueDate);

            text1.setTextColor(Color.BLACK);
            text2.setTextColor(Color.BLACK);

            if (task.priority == 1 || task.priority == 2) {
                convertView.setBackgroundColor(Color.parseColor("#90EE90"));
            } else if (task.priority == 3) {
                convertView.setBackgroundColor(Color.parseColor("#FFFF99"));
            } else {
                convertView.setBackgroundColor(Color.parseColor("#FF6666"));
            }

            if (isDueSoon(task.dueDate)) {
                text2.setTextColor(Color.RED);
                text2.setText("Приоритет: " + task.priority +
                        " | Категория: " + getCategoryText(task.category) +
                        " | Срок: " + task.dueDate);
            }
        }

        convertView.setPadding(20, 16, 20, 16);
        return convertView;
    }

    private boolean isDueSoon(String dueDate) {
        if (dueDate == null || dueDate.isEmpty()) {
            return false;
        }

        try {
            SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy", Locale.getDefault());
            Date due = format.parse(dueDate);
            Date now = new Date();

            long diff = due.getTime() - now.getTime();
            long days = diff / (1000 * 60 * 60 * 24);

            return days >= 0 && days < 2;
        } catch (Exception e) {
            return false;
        }
    }

    private String getStatusText(String status) {
        if ("new".equals(status)) return "Новая";
        if ("in_progress".equals(status)) return "В работе";
        if ("done".equals(status)) return "Выполнена";
        return status;
    }

    private String getCategoryText(String category) {
        if ("work".equals(category)) return "Работа";
        if ("personal".equals(category)) return "Личное";
        if ("study".equals(category)) return "Учёба";
        if ("other".equals(category)) return "Другое";
        return category;
    }
}