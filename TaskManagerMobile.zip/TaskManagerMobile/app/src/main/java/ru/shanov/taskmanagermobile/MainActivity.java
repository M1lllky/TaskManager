package ru.shanov.taskmanagermobile;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.*;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    Spinner spinnerStatus, spinnerPriority, spinnerCategory, spinnerSort;
    EditText editSearch;
    Button buttonAdd, buttonPrev, buttonNext;
    TextView textPage;
    int currentPage = 1;
    final int PAGE_SIZE = 10;
    ListView listTasks;

    DatabaseHelper dbHelper;
    ArrayList<Task> tasks;
    TaskAdapter adapter;

    String[] statuses = {"Все", "Новая", "В работе", "Выполнена"};
    String[] statusValues = {"all", "new", "in_progress", "done"};

    String[] priorities = {"Все", "1", "2", "3", "4", "5"};
    String[] categories = {"Все", "Работа", "Личное", "Учёба", "Другое"};
    String[] categoryValues = {"all", "work", "personal", "study", "other"};

    String[] sorts = {
            "Дата создания: новые сначала",
            "Дата создания: старые сначала",
            "Приоритет: высокий сначала",
            "Приоритет: низкий сначала",
            "Срок: ближайшие сначала",
            "Срок: дальние сначала"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        spinnerStatus = findViewById(R.id.spinnerStatus);
        spinnerPriority = findViewById(R.id.spinnerPriority);
        spinnerCategory = findViewById(R.id.spinnerCategory);
        spinnerSort = findViewById(R.id.spinnerSort);
        editSearch = findViewById(R.id.editSearch);
        buttonAdd = findViewById(R.id.buttonAdd);
        buttonPrev = findViewById(R.id.buttonPrev);
        buttonNext = findViewById(R.id.buttonNext);
        textPage = findViewById(R.id.textPage);
        listTasks = findViewById(R.id.listTasks);

        dbHelper = new DatabaseHelper(this);
        tasks = new ArrayList<>();
        adapter = new TaskAdapter(this, tasks);
        listTasks.setAdapter(adapter);

        spinnerStatus.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, statuses));
        spinnerPriority.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, priorities));
        spinnerCategory.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, categories));
        spinnerSort.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, sorts));

        AdapterView.OnItemSelectedListener filterListener = new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                currentPage = 1;
                loadTasks();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) { }
        };

        spinnerStatus.setOnItemSelectedListener(filterListener);
        spinnerPriority.setOnItemSelectedListener(filterListener);
        spinnerCategory.setOnItemSelectedListener(filterListener);
        spinnerSort.setOnItemSelectedListener(filterListener);

        editSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                currentPage = 1;
                loadTasks();
            }

            @Override
            public void afterTextChanged(Editable s) { }
        });

        buttonAdd.setOnClickListener(v -> showTaskDialog(null));

        buttonPrev.setOnClickListener(v -> {
            if (currentPage > 1) {
                currentPage--;
                loadTasks();
            }
        });

        buttonNext.setOnClickListener(v -> {
            currentPage++;
            loadTasks();
        });

        listTasks.setOnItemClickListener((parent, view, position, id) -> {
            Task task = tasks.get(position);
            showDescription(task);
        });

        listTasks.setOnItemLongClickListener((parent, view, position, id) -> {
            Task task = tasks.get(position);
            showActions(task);
            return true;
        });

        loadTasks();
    }

    private void loadTasks() {
        tasks.clear();

        SQLiteDatabase db = dbHelper.getReadableDatabase();

        String query = "SELECT * FROM " + DatabaseHelper.TABLE_TASKS + " WHERE 1=1";
        ArrayList<String> args = new ArrayList<>();

        int statusPos = spinnerStatus.getSelectedItemPosition();
        int priorityPos = spinnerPriority.getSelectedItemPosition();
        int categoryPos = spinnerCategory.getSelectedItemPosition();
        String search = editSearch.getText().toString().trim();

        if (statusPos > 0) {
            query += " AND " + DatabaseHelper.COLUMN_STATUS + "=?";
            args.add(statusValues[statusPos]);
        }

        if (priorityPos > 0) {
            query += " AND " + DatabaseHelper.COLUMN_PRIORITY + "=?";
            args.add(priorities[priorityPos]);
        }

        if (categoryPos > 0) {
            query += " AND " + DatabaseHelper.COLUMN_CATEGORY + "=?";
            args.add(categoryValues[categoryPos]);
        }

        if (!search.isEmpty()) {
            query += " AND " + DatabaseHelper.COLUMN_TITLE + " LIKE ?";
            args.add("%" + search + "%");
        }

        int sortPos = spinnerSort.getSelectedItemPosition();

        switch (sortPos) {
            case 1:
                query += " ORDER BY " + DatabaseHelper.COLUMN_ID + " ASC";
                break;
            case 2:
                query += " ORDER BY " + DatabaseHelper.COLUMN_PRIORITY + " DESC";
                break;
            case 3:
                query += " ORDER BY " + DatabaseHelper.COLUMN_PRIORITY + " ASC";
                break;
            case 4:
                query += " ORDER BY " + DatabaseHelper.COLUMN_DUE_DATE + " ASC";
                break;
            case 5:
                query += " ORDER BY " + DatabaseHelper.COLUMN_DUE_DATE + " DESC";
                break;
            default:
                query += " ORDER BY " + DatabaseHelper.COLUMN_ID + " DESC";
                break;
        }

        query += " LIMIT " + PAGE_SIZE + " OFFSET " + ((currentPage - 1) * PAGE_SIZE);
        Cursor cursor = db.rawQuery(query, args.toArray(new String[0]));

        while (cursor.moveToNext()) {
            Task task = new Task(
                    cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ID)),
                    cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_TITLE)),
                    cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_DESCRIPTION)),
                    cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_STATUS)),
                    cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_PRIORITY)),
                    cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_CATEGORY)),
                    cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_DUE_DATE)),
                    cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_CREATED_AT))
            );

            tasks.add(task);
        }

        cursor.close();
        db.close();

        adapter.notifyDataSetChanged();

        textPage.setText("Страница: " + currentPage);
        buttonPrev.setEnabled(currentPage > 1);
        buttonNext.setEnabled(tasks.size() == PAGE_SIZE);

    }

    private void showTaskDialog(Task task) {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(40, 20, 40, 10);

        EditText editTitle = new EditText(this);
        editTitle.setHint("Название");
        layout.addView(editTitle);

        EditText editDescription = new EditText(this);
        editDescription.setHint("Описание");
        layout.addView(editDescription);

        Spinner dialogStatus = new Spinner(this);
        dialogStatus.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item,
                new String[]{"Новая", "В работе", "Выполнена"}));
        layout.addView(dialogStatus);

        Spinner dialogPriority = new Spinner(this);
        dialogPriority.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item,
                new String[]{"1", "2", "3", "4", "5"}));
        layout.addView(dialogPriority);

        Spinner dialogCategory = new Spinner(this);
        dialogCategory.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item,
                new String[]{"Работа", "Личное", "Учёба", "Другое"}));
        layout.addView(dialogCategory);

        EditText editDueDate = new EditText(this);
        editDueDate.setHint("Срок выполнения: дд.мм.гггг");
        editDueDate.setFocusable(false);
        layout.addView(editDueDate);

        editDueDate.setOnClickListener(v -> {
            Calendar calendar = Calendar.getInstance();

            DatePickerDialog datePickerDialog = new DatePickerDialog(
                    this,
                    (view, year, month, dayOfMonth) -> {
                        String date = String.format(
                                Locale.getDefault(),
                                "%02d.%02d.%04d",
                                dayOfMonth,
                                month + 1,
                                year
                        );

                        editDueDate.setText(date);
                    },
                    calendar.get(Calendar.YEAR),
                    calendar.get(Calendar.MONTH),
                    calendar.get(Calendar.DAY_OF_MONTH)
            );

            datePickerDialog.show();
        });

        if (task != null) {
            editTitle.setText(task.title);
            editDescription.setText(task.description);
            dialogStatus.setSelection(getStatusPosition(task.status));
            dialogPriority.setSelection(task.priority - 1);
            dialogCategory.setSelection(getCategoryPosition(task.category));
            editDueDate.setText(task.dueDate);
        }

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(task == null ? "Новая задача" : "Редактировать задачу");
        builder.setView(layout);

        builder.setPositiveButton("Сохранить", (dialog, which) -> {
            String title = editTitle.getText().toString().trim();
            String description = editDescription.getText().toString().trim();
            String status = statusValues[dialogStatus.getSelectedItemPosition() + 1];
            int priority = Integer.parseInt(dialogPriority.getSelectedItem().toString());
            String category = categoryValues[dialogCategory.getSelectedItemPosition() + 1];
            String dueDate = editDueDate.getText().toString().trim();

            if (title.isEmpty()) {
                Toast.makeText(this, "Название не может быть пустым", Toast.LENGTH_SHORT).show();
                return;
            }

            if (task == null) {
                insertTask(title, description, status, priority, category, dueDate);
            } else {
                updateTask(task.id, title, description, status, priority, category, dueDate);
            }

            loadTasks();

            textPage.setText("Страница: " + currentPage);
            buttonPrev.setEnabled(currentPage > 1);
            buttonNext.setEnabled(tasks.size() == PAGE_SIZE);
        });

        builder.setNegativeButton("Отмена", null);
        builder.show();
    }

    private void insertTask(String title, String description, String status, int priority, String category, String dueDate) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_TITLE, title);
        values.put(DatabaseHelper.COLUMN_DESCRIPTION, description);
        values.put(DatabaseHelper.COLUMN_STATUS, status);
        values.put(DatabaseHelper.COLUMN_PRIORITY, priority);
        values.put(DatabaseHelper.COLUMN_CATEGORY, category);
        values.put(DatabaseHelper.COLUMN_DUE_DATE, dueDate);
        values.put(DatabaseHelper.COLUMN_CREATED_AT,
                new SimpleDateFormat("dd.MM.yyyy HH:mm:ss", Locale.getDefault()).format(new Date()));

        db.insert(DatabaseHelper.TABLE_TASKS, null, values);
        db.close();
    }

    private void updateTask(int id, String title, String description, String status, int priority, String category, String dueDate) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_TITLE, title);
        values.put(DatabaseHelper.COLUMN_DESCRIPTION, description);
        values.put(DatabaseHelper.COLUMN_STATUS, status);
        values.put(DatabaseHelper.COLUMN_PRIORITY, priority);
        values.put(DatabaseHelper.COLUMN_CATEGORY, category);
        values.put(DatabaseHelper.COLUMN_DUE_DATE, dueDate);

        db.update(DatabaseHelper.TABLE_TASKS, values, DatabaseHelper.COLUMN_ID + "=?", new String[]{String.valueOf(id)});
        db.close();
    }

    private void deleteTask(int id) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.delete(DatabaseHelper.TABLE_TASKS, DatabaseHelper.COLUMN_ID + "=?", new String[]{String.valueOf(id)});
        db.close();
        loadTasks();
    }

    private void showDescription(Task task) {
        new AlertDialog.Builder(this)
                .setTitle(task.title)
                .setMessage(task.description == null || task.description.isEmpty() ? "Нет описания" : task.description)
                .setPositiveButton("OK", null)
                .show();
    }

    private void showActions(Task task) {
        String[] actions;

        if ("done".equals(task.status)) {
            actions = new String[]{"Удалить"};
        } else {
            actions = new String[]{"Редактировать", "Удалить"};
        }

        new AlertDialog.Builder(this)
                .setTitle(task.title)
                .setItems(actions, (dialog, which) -> {
                    if (actions[which].equals("Редактировать")) {
                        showTaskDialog(task);
                    } else {
                        confirmDelete(task);
                    }
                })
                .show();
    }

    private void confirmDelete(Task task) {
        new AlertDialog.Builder(this)
                .setTitle("Удаление")
                .setMessage("Удалить задачу?")
                .setPositiveButton("Да", (dialog, which) -> deleteTask(task.id))
                .setNegativeButton("Нет", null)
                .show();
    }

    private int getStatusPosition(String status) {
        if ("new".equals(status)) return 0;
        if ("in_progress".equals(status)) return 1;
        if ("done".equals(status)) return 2;
        return 0;
    }

    private int getCategoryPosition(String category) {
        if ("work".equals(category)) return 0;
        if ("personal".equals(category)) return 1;
        if ("study".equals(category)) return 2;
        if ("other".equals(category)) return 3;
        return 0;
    }
}